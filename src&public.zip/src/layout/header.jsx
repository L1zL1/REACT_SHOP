function Header() {
    return <nav >
        <div className="container">
            <div class="nav-wrapper">
                <a href="!#" className="brand-logo">React Shop</a>
                <ul id="nav-mobile" className="right hide-on-med-and-down">
                    <li><a href="!#">Repository</a></li>
                </ul>
            </div>
        </div>
    </nav>
}

export { Header };